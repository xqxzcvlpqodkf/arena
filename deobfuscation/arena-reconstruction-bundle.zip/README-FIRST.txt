Upload arena-reconstruction-bundle.zip to Arena.ai and paste the contents of ARENA_UPLOAD_MESSAGE.txt. The agent must read ARENA_TASK.md first.
