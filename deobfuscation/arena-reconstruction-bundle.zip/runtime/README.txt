These files are for controlled analysis in Arena's sandbox.

Bundled binaries: run `chmod +x runtime/luau runtime/luau-compile`, then use `runtime/luau runtime/instrumented-vm.luau > runtime-output.txt`.
Parse a new dump with `python3 runtime/tools/parse_vm_dump.py runtime-output.txt`.

The instrumented runner dumps VM state without executing the recovered root payload. Make a working copy before adding root/callback execution patches.
Never run the protected source in Roblox or a live executor.
